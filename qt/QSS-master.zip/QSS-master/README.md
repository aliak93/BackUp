### QT StyleSheet templates ###
Themes available:
1. [Ubuntu](https://github.com/GTRONICK/QSS/blob/master/Ubuntu.qss)

![Ubuntu theme screenshot](https://sites.google.com/site/gtronick/QSS-Ubuntu.png)
    
2. [ElegantDark](https://github.com/GTRONICK/QSS/blob/master/ElegantDark.qss)

![ElegantDark theme screenshot](https://sites.google.com/site/gtronick/QSS-ElegantDark.png)
    
3. [MaterialDark](https://github.com/GTRONICK/QSS/blob/master/MaterialDark.qss)

![MaterialDark theme screenshot](https://sites.google.com/site/gtronick/QSS-MaterialDark.png)
    
4. [ConsoleStyle](https://github.com/GTRONICK/QSS/blob/master/ConsoleStyle.qss)

![ConsoleStyle theme screenshot](https://sites.google.com/site/gtronick/QSS-ConsoleStyle.png)
    
5. [AMOLED](https://github.com/GTRONICK/QSS/blob/master/AMOLED.qss)

![AMOLED theme screenshot](https://sites.google.com/site/gtronick/QSS-Amoled.png)
    
6. [Aqua](https://github.com/GTRONICK/QSS/blob/master/Aqua.qss)

![Aqua theme screenshot](https://sites.google.com/site/gtronick/QSS-Aqua.png)

## The ManjaroMix Theme!: Includes a radial gradient for Checkboxes, and minimalist arrows for scrollbars. ##
7. [ManjaroMix](https://github.com/GTRONICK/QSS/blob/master/ManjaroMix.qss)

![ManjaroMix theme screenshot](https://5c57bd3a-a-62cb3a1a-s-sites.googlegroups.com/site/gtronick/QSS-ManajaroMix.PNG)

8. [NeonButtons](https://github.com/GTRONICK/QSS/blob/master/NeonButtons.qss)

![NeonButtons screenshot](https://sites.google.com/site/gtronick/NeonActive.png)
![NeonButtons screenshot](https://sites.google.com/site/gtronick/NeonClick.png)

## MacOS Theme!: Reduced code, image integration through URL resources. ##
9. [MacOS](https://github.com/GTRONICK/QSS/blob/master/MacOS.qss)

![MacOS](https://sites.google.com/site/gtronick/QSS-MacOS.png)    
Stay tunned!, this files are being updated frequently.

*Consider donating :)* **PayPal Account:** gtronick@gmail.com 

