#!/usr/bin/bash

source /home/yeison/Development/BCI-Framework/venv/bin/activate
jupyter-lab --notebook-dir='.'
