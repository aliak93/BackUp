

.. include:: notebooks/readme.rst

Navigation
----------

.. toctree::
   :maxdepth: 2
   :name: mastertoc

   

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

    