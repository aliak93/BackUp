.. automodule:: qt_material.resources.generate
   :members:
   :no-undoc-members:
   :no-show-inheritance:
