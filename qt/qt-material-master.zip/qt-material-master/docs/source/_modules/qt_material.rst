qt\_material package
====================

.. automodule:: qt_material
   :members:
   :no-undoc-members:
   :no-show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   qt_material.resources

Submodules
----------

.. toctree::
   :maxdepth: 4

   qt_material.hook-qt_material
