qt\_material.resources package
==============================

.. automodule:: qt_material.resources
   :members:
   :no-undoc-members:
   :no-show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   qt_material.resources.logo
   qt_material.resources.source

Submodules
----------

.. toctree::
   :maxdepth: 4

   qt_material.resources.generate
