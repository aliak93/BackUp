qt\_material.resources.logo package
===================================

.. automodule:: qt_material.resources.logo
   :members:
   :no-undoc-members:
   :no-show-inheritance:
