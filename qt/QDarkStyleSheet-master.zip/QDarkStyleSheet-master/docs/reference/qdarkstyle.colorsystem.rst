qdarkstyle.colorsystem module
=============================

.. automodule:: qdarkstyle.colorsystem
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
