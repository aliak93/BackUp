qdarkstyle.dark.style\_rc module
================================

.. automodule:: qdarkstyle.dark.style_rc
   :members:
   :undoc-members:
   :show-inheritance:
   :private-members:
