Screenshots
===========


Screenshots
-----------

Here are a few snapshots comparing the use of QDarkStyle and the
default style. Click in the image to zoom.


Containers (no tabs) and Buttons
--------------------------------

.. image:: images/dark/containers_no_tabs_buttons.png

.. image:: images/light/containers_no_tabs_buttons.png

.. image:: images/none/containers_no_tabs_buttons.png


Containers (tabs) and Displays
------------------------------

.. image:: images/dark/containers_tabs_displays.png

.. image:: images/light/containers_tabs_displays.png

.. image:: images/none/containers_tabs_displays.png


Widgets and Inputs (fields)
---------------------------

.. image:: images/dark/widgets_inputs_fields.png

.. image:: images/light/widgets_inputs_fields.png

.. image:: images/none/widgets_inputs_fields.png


Views and Inputs (no fields)
----------------------------

.. image:: images/dark/views_inputs_no_fields.png

.. image:: images/light/views_inputs_no_fields.png

.. image:: images/none/views_inputs_no_fields.png
