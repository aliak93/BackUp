# nodejs-passport-sequelize
An authentication API fully tested using express, nodejs, passport, sequelize and mysql

to run the app:


1**
install the dependencies first:
  npm install

2**
you must create a database in mysql
  create database 'database_name';
  
3**
start the server inside of the project root
  node server.js




